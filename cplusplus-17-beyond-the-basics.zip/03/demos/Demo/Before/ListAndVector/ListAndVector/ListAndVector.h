#pragma once

void BuildVector(const int& size);

void BuildList(const int& size);
