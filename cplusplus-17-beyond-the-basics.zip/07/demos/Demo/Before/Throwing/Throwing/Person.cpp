#include "Person.h"
#include <iostream>
#include "Noise.h"

using std::string;
using std::invalid_argument;

Person::Person() : firstname(""), lastname(""), arbitrarynumber(-1)
{
}

Person::Person(string first, string last,
	int arbitrary) : firstname(first), lastname(last),
	arbitrarynumber(arbitrary)
{

	if (arbitrarynumber == 0)
	{
		throw invalid_argument("Arbitrary number for a Person cannot be zero.");
	}
}

