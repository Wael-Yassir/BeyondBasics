#pragma once
#include <string>

class Noise
{
private:
	std::string SoundIMake;
public:
	Noise(std::string);
	~Noise(void);
};

